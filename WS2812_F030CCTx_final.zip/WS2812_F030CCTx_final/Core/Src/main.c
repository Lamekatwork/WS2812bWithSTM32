/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TRUE	1

//#define MAX_LED 8
//#define MAX_LED 100
#define MAX_LED 300  //The LED strip I have has 300 LEDs.
#define nColours	3   //just the number of colors (i.e. r,g,b)
#define USE_BRIGHTNESS 0
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim15;
DMA_HandleTypeDef hdma_tim15_ch1_up_trig_com;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM15_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/*
 * This code has been tested on an LED strip with 300 LEDs and worked well.
 * The delay in the main has to be relatively high with the number of LEDs.
 * If one has only about 10 LEDs a 30ms delay will cut it, but as the number of
 * LEDs increase, the delay need to be increased, just to see the split in LED update
 * Lamek Amunyela 24/11/2022
 */


uint8_t LED_Data[MAX_LED][4];
uint8_t LED_Mod[MAX_LED][4];  // for brightness

int datasentflag=0;

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim)
{
	HAL_TIM_PWM_Stop_DMA(&htim15, TIM_CHANNEL_1);
	datasentflag=1;
}

void Set_LED (int LEDnum, int Red, int Green, int Blue)
{
	LED_Data[LEDnum][0] = LEDnum;
	LED_Data[LEDnum][1] = Green;
	LED_Data[LEDnum][2] = Red;
	LED_Data[LEDnum][3] = Blue;
}

#define PI 3.14159265

void Set_Brightness (int brightness)  // 0-45
{
#if USE_BRIGHTNESS

	if (brightness > 45) brightness = 45;
	for (int i=0; i<MAX_LED; i++)
	{
		LED_Mod[i][0] = LED_Data[i][0];
		for (int j=1; j<4; j++)
		{
			float angle = 90-brightness;  // in degrees
			angle = angle*PI / 180;  // in rad
			LED_Mod[i][j] = (LED_Data[i][j])/(tan(angle));
		}
	}

#endif

}

uint16_t pwmData[(24*MAX_LED)+50];

void WS2812_Send (void)
{
	uint32_t indx=0;
	uint32_t color;


	for (int i= 0; i<MAX_LED; i++)
	{
#if USE_BRIGHTNESS
		color = ((LED_Mod[i][1]<<16) | (LED_Mod[i][2]<<8) | (LED_Mod[i][3]));
#else
		color = ((LED_Data[i][1]<<16) | (LED_Data[i][2]<<8) | (LED_Data[i][3]));
#endif

		for (int i=23; i>=0; i--)
		{
			if (color&(1<<i))
			{
				pwmData[indx] = 40;  // 2/3 of 60
			}

			else pwmData[indx] = 19;  // 1/3 of 60

			indx++;
		}

	}

	for (int i=0; i<50; i++)
	{
		pwmData[indx] = 0;
		indx++;
	}

	HAL_TIM_PWM_Start_DMA(&htim15, TIM_CHANNEL_1, (uint32_t *)pwmData, indx);
	while (!datasentflag){};
	datasentflag = 0;
}

void Reset_LED (void)
{
	for (int i=0; i<MAX_LED; i++)
	{
		LED_Data[i][0] = i;
		LED_Data[i][1] = 0;
		LED_Data[i][2] = 0;
		LED_Data[i][3] = 0;
	}
}

// ported from the arduino code for 8 LEDs located at ->>>>  https://adrianotiger.github.io/Neopixel-Effect-Generator/

uint16_t effStep = 0;

uint8_t rainbow_effect_left() {
    // Strip ID: 0 - Effect: Rainbow - LEDS: 8
    // Steps: 13 - Delay: 54
    // Colors: 3 (255.0.0, 0.255.0, 0.0.255)
    // Options: rainbowlen=8, toLeft=true,
//  if(millis() - strip_0.effStart < 54 * (strip_0.effStep)) return 0x00;

  float factor1, factor2;
  uint16_t ind;
  for(uint16_t j=0;j<MAX_LED;j++) {
    ind = effStep + j * 1.625;
    switch((int)((ind % 13) / 4.333333333333333)) {
      case 0: factor1 = 1.0 - ((float)(ind % 13 - 0 * 4.333333333333333) / 4.333333333333333);
              factor2 = (float)((int)(ind - 0) % 13) / 4.333333333333333;
              /************ chnaged here *********/
              Set_LED(j, 255 * factor1 + 0 * factor2, 0 * factor1 + 255 * factor2, 0 * factor1 + 0 * factor2);
              WS2812_Send();
              break;
      case 1: factor1 = 1.0 - ((float)(ind % 13 - 1 * 4.333333333333333) / 4.333333333333333);
              factor2 = (float)((int)(ind - 4.333333333333333) % 13) / 4.333333333333333;
              Set_LED(j, 0 * factor1 + 0 * factor2, 255 * factor1 + 0 * factor2, 0 * factor1 + 255 * factor2);
              WS2812_Send();
              break;
      case 2: factor1 = 1.0 - ((float)(ind % 13 - 2 * 4.333333333333333) / 4.333333333333333);
              factor2 = (float)((int)(ind - 8.666666666666666) % 13) / 4.333333333333333;
              Set_LED(j, 0 * factor1 + 255 * factor2, 0 * factor1 + 0 * factor2, 255 * factor1 + 0 * factor2);
              WS2812_Send();
              break;
    }
  }
  if(effStep >= 13) {effStep=0; return 0x03; }
  else effStep++;
  return 0x01;
}



uint8_t rainbow_effect_right() {
    // Strip ID: 0 - Effect: Rainbow - LEDS: 8
    // Steps: 14 - Delay: 30
    // Colors: 3 (255.0.0, 0.255.0, 0.0.255)
    // Options: rainbowlen=8, toLeft=false,
//  if(millis() - strip_0.effStart < 30 * (strip_0.effStep)) return 0x00;
  float factor1, factor2;
  uint16_t ind;
  for(uint16_t j=0;j<MAX_LED;j++) {
    ind = 14 - (int16_t)(effStep - j * 1.75) % 14;
    switch((int)((ind % 14) / 4.666666666666667)) {
      case 0: factor1 = 1.0 - ((float)(ind % 14 - 0 * 4.666666666666667) / 4.666666666666667);
              factor2 = (float)((int)(ind - 0) % 14) / 4.666666666666667;
              Set_LED(j, 255 * factor1 + 0 * factor2, 0 * factor1 + 255 * factor2, 0 * factor1 + 0 * factor2);
              WS2812_Send();
              break;
      case 1: factor1 = 1.0 - ((float)(ind % 14 - 1 * 4.666666666666667) / 4.666666666666667);
              factor2 = (float)((int)(ind - 4.666666666666667) % 14) / 4.666666666666667;
              Set_LED(j, 0 * factor1 + 0 * factor2, 255 * factor1 + 0 * factor2, 0 * factor1 + 255 * factor2);
              WS2812_Send();
              break;
      case 2: factor1 = 1.0 - ((float)(ind % 14 - 2 * 4.666666666666667) / 4.666666666666667);
              factor2 = (float)((int)(ind - 9.333333333333334) % 14) / 4.666666666666667;
              Set_LED(j, 0 * factor1 + 255 * factor2, 0 * factor1 + 0 * factor2, 255 * factor1 + 0 * factor2);
              WS2812_Send();
              break;
    }
  }
  if(effStep >= 14) {effStep = 0; return 0x03; }
  else effStep++;
  return 0x01;
}


//////These are functions that i have ported from randomNurd for WS2812B LED Strip////////////////////////////////////////
/*https://randomnerdtutorials.com/micropython-ws2812b-addressable-rgb-leds-neopixel-esp32-esp8266/*/
int setLED[MAX_LED][nColours];

int * wheel(int pos)
{
    static int r[nColours];
    if(pos <0 || pos >255)
    {
        for(int i = 0; i<nColours;i++)
        {
            r[i]= 0;
        }
        return r;
    }
    if (pos < 85)
    {
        r[0] = (255 - pos * 3);
        r[1] = (pos * 3);
        r[2] = 0;
        return r;
    }
    if (pos < 170)
    {
        pos -= 85;
        r[0] = 0;
        r[1] = (255 - pos * 3);
        r[2] = (pos * 3);
        return r;
    }
    else{
        pos -= 170;
        r[0]= (pos *3);
        r[1] = 0;
        r[2] = (255-pos*3);
        return r;
    }
}

void rainbow_cycle(int wait)  //This function set the rainbow color which run 255 times with a delay. This function worked well
//void rainbow_cycle()
{
    for (int j=0;j<255;j++)
    {
        for (int i=0;i<MAX_LED;i++)
        {
            int rc_index = floor((i * 256)/ MAX_LED) + j;
            //printf("%d ", rc_index);
            int *p = wheel(rc_index & 255);
            //now print out the array of color *p
            for (int x = 0;x<nColours;x++ )
            {
                //printf( "*(p + %d) : %d\n", x, *(p + x));
                setLED[i][x] = *(p+x);
            }
            Set_LED(i, setLED[i][0], setLED[i][1], setLED[i][2]);
            WS2812_Send();
            HAL_Delay(wait);
            //printf("\n");
            //print2DArray(setLED);
            //WS2812bSend();//np.write()
            //printf("Delay(%d ms)\n",wait);



        }

    }

}


//The setColour function set all LED on the strip to the same colour
void setColours(int r,int g,int b) //The set colour function worked well
{
	for(int i = 0;i<MAX_LED;i++)
	{
		Set_LED(i, r, g, b);
		WS2812_Send();
	}
}

//The bounce function make an LED which is off to run to and fro in the LED strip
//This function worked well
void bounce(int r,int g,int b,int wait)
{
	for(int i =0; i<(4*MAX_LED);i++)
	{
		for(int j=0; j<MAX_LED;j++)
		{
			Set_LED(j, r, g, b);
		}
		int z = floor((i/MAX_LED));
		//if(floor((i/MAX_LED))%2==0)
		if(z%2 == 0)
		{
			Set_LED(i%MAX_LED, 0, 0, 0);
		}
		else
		{
			Set_LED((MAX_LED-1-(i%MAX_LED)), 0, 0, 0);
		}
		WS2812_Send();
		HAL_Delay(wait);
	}
}

void Cycle(int r,int g, int b, int wait)
{
	for(int i=0;i<4*MAX_LED;i++)
	{
		for(int j=0; j<MAX_LED;j++)
		{
			Set_LED(j, 0, 0, 0);
		}
		Set_LED(i%MAX_LED, r, g, b);
		WS2812_Send();
		HAL_Delay(wait);
	}
}


//fade in/out  char str[]
//void fadeInOut(int colour, wait)
void fadeInOut(char str[],int wait)
{
	int val;
	for(int i = 0; i<(4*256);i+=8)
	{
		for(int j =0; j<MAX_LED;j++)
		{
			int z = floor(i/256);
			//if(floor((i / 256))%2 ==0)
			if(z%2 ==0)
			{
				val = i & 0xff;
			}
			else
			{
				val =255-(i & 0xff);
			}
		    if(strcmp("red", str)==0)
		    {
		    	Set_LED(j, val, 0, 0);
		    }
		    else if(strcmp("green", str)==0)
		    {
		    	Set_LED(j, 0, val, 0);
		    }
		    else if(strcmp("blue", str)==0)
		    {
		    	Set_LED(j, 0, 0, val);
		    }
		    else if(strcmp("purple", str)==0)
		    {
		    	Set_LED(j, val, 0, val);
		    }
		    else if(strcmp("yellow", str)==0)
		    {
		    	Set_LED(j, val, val, 0);
		    }
		    else if(strcmp("teal", str)==0)
		    {
		    	Set_LED(j, 0, val, val);
		    }
		    else if(strcmp("white", str)==0)
		    {
		    	Set_LED(j, val, val, val);
		    }
		    WS2812_Send();
		    HAL_Delay(wait);
		}
	}
}

void showColours(void)
{
	setColours(255,0,0);    //set them all red
		  HAL_Delay(100);
		  setColours(0,255,0);    //set them all green
		  HAL_Delay(100);
		  setColours(0,0,255);    //set them all blue
		  HAL_Delay(100);

		  setColours(0,102,230);    //set them all lift blue;
		  HAL_Delay(100);
		  setColours(120,153,23);    //set them all light green
		  HAL_Delay(100);
		  setColours(255,0,153);    //set them all purple ->
		  HAL_Delay(100);

	//	  setColours(255,0,0);    //set them all red;
	//	  HAL_Delay(100);
	//	  setColours(255,223,0);    //set them all gold;
	//	  HAL_Delay(100);
	////	  setColours(230,230,250);    //set them all purple ->lavender
	////	  setColours(216,191,216);    //set them all purple ->thistle

		  //setColours(0,255,0);    //set them all green
		 // HAL_Delay(100);
}



//This function turns off all LED on the LED strip.
void ClearLEDsStrip(void)  //This function worked well
{
	for(int i= 0; i<MAX_LED;i++)
	{
		Set_LED(i, setLED[i][0], setLED[i][1], setLED[i][2]);
		WS2812_Send();
	}

}

//////////////////////////Ported functions ends here//////////////////////////////////////////////////////////////////////

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM3_Init();
  MX_TIM15_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim3);  //Start timer3 in the interrupt mode

  //For testing PWM frequency and duty-cycle only
//  HAL_TIM_PWM_Start(&htim15, TIM_CHANNEL_1); //start PWM with timer15 on channel one
//  htim15.Instance->CCR1 = 19;



  Set_LED(0, 255, 0, 0);
  Set_LED(1, 0, 255, 0);
  Set_LED(2, 0, 0, 255);

  Set_LED(3, 46, 89, 128);

  Set_LED(4, 156, 233, 100);
  Set_LED(5, 102, 0, 235);
  Set_LED(6, 47, 38, 77);

  Set_LED(7, 255, 200, 0);



  Set_LED(8, 0, 255, 0);
  Set_LED(9, 0, 0, 255);

  Set_LED(10, 46, 89, 128);

  Set_LED(11, 156, 233, 100);
  Set_LED(12, 102, 0, 235);
  Set_LED(13, 47, 38, 77);
  Set_LED(14, 255, 200, 0);

  Set_LED(15, 0, 255, 0);
  Set_LED(16, 0, 0, 255);

  Set_LED(17, 46, 89, 128);

  Set_LED(18, 156, 233, 100);
  Set_LED(19, 102, 0, 235);
  Set_LED(20, 47, 38, 77);
  Set_LED(21, 255, 200, 0);

  Set_Brightness(10);
  WS2812_Send();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (TRUE)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	//08/12/2022

//	  setColours(255,0,0);    //set them all red
//	  HAL_Delay(100);
//	  setColours(0,255,0);    //set them all green
//	  HAL_Delay(100);
//	  setColours(0,0,255);    //set them all blue
//	  HAL_Delay(100);
//
//	  setColours(0,102,230);    //set them all lift blue;
//	  HAL_Delay(100);
//	  setColours(120,153,23);    //set them all light green
//	  HAL_Delay(100);
//	  setColours(255,0,153);    //set them all purple ->
//	  HAL_Delay(100);
//
////	  setColours(255,0,0);    //set them all red;
////	  HAL_Delay(100);
////	  setColours(255,223,0);    //set them all gold;
////	  HAL_Delay(100);
//////	  setColours(230,230,250);    //set them all purple ->lavender
//////	  setColours(216,191,216);    //set them all purple ->thistle
//
//	  //setColours(0,255,0);    //set them all green
//	 // HAL_Delay(100);
	  showColours();   //send individual colours for all LEDs on the strip


	  bounce(0,255,0,50); //gree colour with a 100ms delay
	  //bounce(255, 0, 125, 50);
	  Cycle(0,255,0,50);

//	  fadeInOut("green", 10);
//	  fadeInOut("yellow", 10);
	  fadeInOut("blue", 10);


//	  //rainbow_cycle(10);
	  rainbow_cycle(2);
	  ClearLEDsStrip();
	  HAL_Delay(1000);  //pause for 1 second



////This part worked before////// on the second day
//	  rainbow_effect_right();
//	 // HAL_Delay (30);
//	  HAL_Delay (1000);





	  //	  for (int i=0; i<46; i++)
	  //	  {
	  //		  Set_Brightness(i);
	  //		  WS2812_Send();
	  //		  HAL_Delay (50);
	  //	  }
	  //
	  //	  for (int i=45; i>=0; i--)
	  //	  {
	  //		  Set_Brightness(i);
	  //		  WS2812_Send();
	  //		  HAL_Delay (50);
	  //	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 4800;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 5000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM15 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM15_Init(void)
{

  /* USER CODE BEGIN TIM15_Init 0 */

  /* USER CODE END TIM15_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM15_Init 1 */

  /* USER CODE END TIM15_Init 1 */
  htim15.Instance = TIM15;
  htim15.Init.Prescaler = 0;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = 60-1;
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.RepetitionCounter = 0;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim15, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim15, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim15, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM15_Init 2 */

  /* USER CODE END TIM15_Init 2 */
  HAL_TIM_MspPostInit(&htim15);

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel4_5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
